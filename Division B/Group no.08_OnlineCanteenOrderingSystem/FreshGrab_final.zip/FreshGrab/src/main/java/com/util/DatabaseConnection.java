package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To create a JDBC Connection steps are
 * 
 * 1. Import all the packages 
 * 2. Register the JDBC Driver 
 * 3. Open a connection 
 * 4. Execute the query, and retrieve the result 
 * 5. Clean up the JDBC Environment
 */

//This class can be used to initialize the database connection
public class DatabaseConnection {
 public static Connection initializeDatabase()
     throws SQLException, ClassNotFoundException {
	 
     // Initialize all the information regarding
     // Database Connection
     String dbDriver = "com.mysql.jdbc.Driver";
     String dbURL = "jdbc:mysql://localhost:3306/";
     // Database name to access
     String dbName = "freshgrabdb";
     String dbUsername = "root";
     String dbPassword = "root";

     Class.forName(dbDriver);
     Connection con = DriverManager.getConnection(dbURL + dbName + "?characterEncoding=utf8&elideSetAutoCommits=true&enabledTLSProtocols=TLSv1.2",
                                                  dbUsername, 
                                                  dbPassword);
     return con;
 }
}
