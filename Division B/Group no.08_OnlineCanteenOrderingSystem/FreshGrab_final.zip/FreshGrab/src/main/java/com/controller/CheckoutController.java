package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;
import com.util.DatabaseConnection;

public class CheckoutController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	  protected void doPost(HttpServletRequest request, 
			  HttpServletResponse response) throws ServletException, IOException {
		  System.out.println("I am here at CheckoutController ");
		  
		  String item1Qty = request.getParameter("item1Qty");
		  System.out.println("Item 1 qty "+item1Qty);
		  
		  String item2Qty = request.getParameter("item2Qty");
		  System.out.println("Item 2 qty "+item2Qty);
		  
		  String item3Qty = request.getParameter("item3Qty");
		  System.out.println("Item 3 qty "+item3Qty);
		  
		  String item4Qty = request.getParameter("item4Qty");
		  System.out.println("Item 4 qty "+item4Qty);
		  
		  String billAmount = request.getParameter("billAmount");
		  System.out.println("billAmount "+billAmount);
		  
		// Initialize the database
          try {
			Connection con = DatabaseConnection.initializeDatabase();
			
			PreparedStatement prepStat = con
	                   .prepareStatement("insert into tblorder ( customer_id, order_date, total_amount) values (?, ?, ?)",Statement.RETURN_GENERATED_KEYS);
	           
	            prepStat.setInt(1, 1);
	            long datetime = new Date().getTime();
	            prepStat.setDate(2, new java.sql.Date(datetime));
	            prepStat.setDouble(3, Double.parseDouble(billAmount));
	           
	            // Execute the insert command using executeUpdate()
	            // to make changes in database
	            prepStat.executeUpdate();
	            
	            ResultSet rs = prepStat.getGeneratedKeys();
	            int genratedOrderId=0;
	            if (rs.next()) {
	            	genratedOrderId = rs.getInt(1);
	            }
	  
	            // Close all the connections
	            prepStat.close();

	            System.out.println("genratedOrderId "+genratedOrderId);
	            
	            if(item1Qty != null && item1Qty != "" && Integer.parseInt(item1Qty)> 0) {
	            	int qty = Integer.parseInt(item1Qty);
	            	insertIntoOrderDetails(con, genratedOrderId, 12.0, qty, (qty * 12.0));   	
	            }	
	            
	            if(item2Qty != null && item2Qty != "" && Integer.parseInt(item2Qty)> 0) {
	            	int qty = Integer.parseInt(item2Qty);
	            	insertIntoOrderDetails(con, genratedOrderId, 25.0, qty, (qty * 25.0));        	
	            }
	            
	            if(item3Qty != null && item3Qty != "" && Integer.parseInt(item3Qty)> 0) {
	            	int qty1 = Integer.parseInt(item3Qty);
	            	insertIntoOrderDetails(con, genratedOrderId, 10.0, qty1, (qty1 * 10.0));	        	
	            }	  
	            
	            if(item4Qty != null && item4Qty != "" && Integer.parseInt(item4Qty)> 0) {
	            	int qty1 = Integer.parseInt(item4Qty);
	            	insertIntoOrderDetails(con, genratedOrderId, 15.0, qty1, (qty1 * 15.0));	        	
	            }	 
            
            con.close();
            
		
          } catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  RequestDispatcher rd=request.getRequestDispatcher("checkout.html");  
          rd.forward(request,response); 
	  }
	  
	  private void insertIntoOrderDetails(Connection con, int orderId, double amount, int qty, double totalAmount ) throws SQLException {
		  
		// Create a SQL query to insert data into tblorderdetails table
          PreparedStatement prepStat = con
                 .prepareStatement("insert into tblorderdetails (order_id, amount, no_of_serving, total_amount) values (?, ?, ?, ?)");
          prepStat.setInt(1, orderId);
          prepStat.setDouble(2, amount);
          prepStat.setInt(3, qty);
          prepStat.setDouble(4, totalAmount);
          
          // Execute the insert command using executeUpdate()
          // to make changes in database
          prepStat.executeUpdate();

          // Close all the connections
          prepStat.close();
		  
	  }
}
