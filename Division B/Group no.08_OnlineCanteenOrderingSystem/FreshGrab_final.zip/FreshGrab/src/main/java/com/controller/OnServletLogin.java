package com.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.util.DatabaseConnection;

/**
 * Servlet implementation class OnServletLogin
 */

public class OnServletLogin extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("In Login Validation Servlet");

		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");

		String user = request.getParameter("username");
		String pass = request.getParameter("password");

		try {
			Connection con = DatabaseConnection.initializeDatabase();
			PreparedStatement stmt = con.prepareStatement("select count(*) from tbluser where tblusername = ? and tbluser_password = ? ");  
			stmt.setString(1, user);
			stmt.setString(2, pass);
			ResultSet rs = stmt.executeQuery();  
			rs.next();
				int count = rs.getInt(1);
				System.out.println("count -->"+count);  
			
				// Username - yukti password - 1234
	
				//if (user.equals("yukti") && pass.equals("1234")) {
				if(count > 0) {
					//This is to redirect to show menu page if successful login
					 RequestDispatcher rd=request.getRequestDispatcher("home.html");  
				     rd.include(request,response);  
				} else {							             
		             RequestDispatcher rd=request.getRequestDispatcher("loginFormError.html");  
				     rd.forward(request,response); 
				}
			
			pw.close();
			stmt.close();
			con.close();
		} catch (ClassNotFoundException | SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
