package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;
import com.util.DatabaseConnection;

public class RegistrationController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	  protected void doPost(HttpServletRequest request, 
			  HttpServletResponse response) throws ServletException, IOException {
		  System.out.println("I am here at RegistrationController ");
		  String username = request.getParameter("username");
		  
		  String psw = request.getParameter("psw");	 	  

		// Initialize the database
          try {
			Connection con = DatabaseConnection.initializeDatabase();
			
			PreparedStatement prepStat = con
	                   .prepareStatement("insert into tbluser ( tblusername, tbluser_password) values (?, ?)",Statement.RETURN_GENERATED_KEYS);
	           
	            prepStat.setString(1,username);
	            prepStat.setString(2,psw);
	           
	            // Execute the insert command using executeUpdate()
	            // to make changes in database
	            prepStat.executeUpdate();
	            
	            ResultSet rs = prepStat.getGeneratedKeys();
	            int genratedUserId=0;
	            if (rs.next()) {
	            	genratedUserId = rs.getInt(1);
	            }
	  
	            // Close all the connections
	            prepStat.close();

	            System.out.println("genratedUserId "+genratedUserId);
	            
                con.close();
            
		
          } catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  RequestDispatcher rd=request.getRequestDispatcher("loginForm.html");  
          rd.forward(request,response); 
	  } 
}
